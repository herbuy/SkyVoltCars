<?php

class InvalidInputException extends Exception{
}
class ThrowInvalidInputException{
    public static function given($boolean, $message){
        if($boolean){
            throw new InvalidInputException($message);
        }
    }
    public static function ifNot($boolean,$message){
        self::given(!$boolean,$message);
    }
}

abstract class VariableDefinition{

    private $value;
    public function getValue(){
        return $this->value;
    }
    public function __toString()
    {
        return $this->getValue();
    }

    public function __construct()
    {
        $this->value = $this->resolveValue();
        $this->value = $this->sanitizeValue($this->value);
        if(!$this->valueEmpty($this->value)){
            $this->validateValue($this->value);
        }
        else{
            ThrowInvalidInputException::ifNot($this->canBeNull(), $this->canNotBeNullMessage());
            $this->value = $this->defaultValue();
        }
    }
    private function resolveValue(){
        $value = array_key_exists($this->getName(),$_REQUEST)? trim($_REQUEST[$this->getName()]) : "";
        return $value;
    }
    protected abstract function validateValue($value);
          
    

    /** @return string */
    abstract public function getName();

    /** @return bool */
    protected function canBeNull()
    {
        return false;
    }
    /** @return string */
    abstract protected function defaultValue();

    /**
     * @return string
     */
    private function canNotBeNullMessage()
    {
        return $this->getName() . " can not be empty";
    }

 
    /**
     * @param $value
     * @return bool
     */
    private function valueEmpty($value)
    {
        return $value == "";
    }

    protected function sanitizeValue($value)
    {
        return $value;
    }
}

abstract class EnumVariable extends VariableDefinition{
    protected function validateValue($value)
    {
        $acceptable_values_array = array_flip($this->getArrayOfAcceptableValues());
        ThrowInvalidInputException::ifNot(
            array_key_exists($value,$acceptable_values_array),"invalid value for ".$this->getName());
    }
    abstract protected function getArrayOfAcceptableValues();
}
abstract class CommaSeparatedEnum extends EnumVariable{
    protected function validateValue($value)
    {        
        //break it into comma separated value
        $sub_parts = explode(",",$value);
        //validate each value against the enumeration
        foreach ($sub_parts as $sub_item){
            parent::validateValue($sub_item);
        }
    }
    public function getValueAsArray()
    {
        return explode(",",$this->getValue());        
    }
}

abstract class NonEnumVariable extends VariableDefinition{
    protected function validateValue($value){
        ThrowInvalidInputException::ifNot(strlen($value) >= $this->minLengthInChars(), $this->tooShortMessage());
        ThrowInvalidInputException::ifNot(strlen($value) <= $this->maxLengthInChars(), $this->exceededLengthMessage());
        ThrowInvalidInputException::ifNot($this->matches($value), $this->invalidDataTypeMessage());
        
    }

    /** @return bool */
    protected function matches($value){
        return preg_match(sprintf("/^(%s)$/i",$this->getPattern()),$value);
    }
    abstract protected function getPattern();
    /** @return int */
    abstract protected function maxLengthInChars();
    
    protected function minLengthInChars()
    {
        return 0;
    }

    protected function exceededLengthMessage()
    {
        return sprintf("%s too long",$this->getName());
    }

    protected function tooShortMessage()
    {
        return sprintf("%s too short",$this->getName());
    }

    private function invalidDataTypeMessage()
    {
        return sprintf("%s incorrect", $this->getName());
    }

}

abstract  class TextDefinition extends NonEnumVariable{
    protected function getPattern()
    {
        return "[\w\W\s\S]+";
    }
    
    protected function maxLengthInChars()
    {
        return 160;
    }

    protected function defaultValue()
    {
        return "";
    }
}
abstract class IntegerInputDefinition extends NonEnumVariable{
    protected function defaultValue()
    {
        return 0;
    }
    protected function sanitizeValue($value)
    {
        //allow for commas and spaces in values to group them
        $value = trim($value);
        $value = str_replace(",","",$value);
        $value = preg_replace("/\s+/i","",$value);
        return $value;
    }

    protected function exceededLengthMessage()
    {
        return sprintf("%s too big",$this->getName());
    }

    protected function tooShortMessage()
    {
        return sprintf("%s too small",$this->getName());
    }
}

abstract class BigIntValueDefinition extends IntegerInputDefinition{
        
    protected function maxLengthInChars()
    {
        return 20;
    }
    protected function defaultValue()
    {
        return 0;
    }
    protected function canBeNull()
    {
        return false;
    }
    protected function getPattern(){
        return "\d{1,20}";
    }
}

abstract class IntValueDefinition extends IntegerInputDefinition{

    protected function maxLengthInChars()
    {
        return 9;
    }
    protected function defaultValue()
    {
        return 0;
    }
    protected function canBeNull()
    {
        return false;
    }
    protected function getPattern(){
        return "\d{1,9}";
    }
}
abstract class PositiveIntValueDefinition extends IntValueDefinition{
    
    protected function defaultValue()
    {
        return 1;
    }
    protected function canBeNull()
    {
        return false;
    }
    protected function getPattern(){
        return "[1-9]|[1-9]([0-9]{0,8})";
    }
}


abstract class BooleanValue extends EnumVariable{
    protected function getArrayOfAcceptableValues()
    {
        return array(0,1);
    }

    protected function defaultValue()
    {
        return 0;
    }
}


abstract class Sha1HashedInput extends TextDefinition{
    public function getValue()
    {
        return sha1(parent::getValue());
    }
}
