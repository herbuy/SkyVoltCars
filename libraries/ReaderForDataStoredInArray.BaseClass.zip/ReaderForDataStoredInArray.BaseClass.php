<?php

abstract class BaseClassOfReaderForDataStoredInArray{
    private $array = array();
    public function read_key($key){
        $value = array_key_exists($key,$this->array)? $this->array[$key]:"";
        $value = $this->should_escape_html_special_chars && is_string($value) ? htmlspecialchars($value): $value;
        $value = is_string($value) && $this->should_decode_as_utf8 ? utf8_decode($value): $value;//todo:order matters: encoding should be last!!
        return $value;
    }
    private $should_escape_html_special_chars = true;
    private $should_decode_as_utf8 = false;

    public function dump_array(){
        print json_encode($this->array);
    }

    public function __construct($array)
    {
        $this->throwExceptionIfNotArray($array);
        $this->array = $array;
    }
    public function disable_escape_html_special_chars(){
        $this->should_escape_html_special_chars = false;
    }

    public function iterator(){
        return new ArrayIterator($this->array);
    }
    public function all(){
        return $this->array;
    }
    //todo: rename to all
    public function get_array(){
        return  $this->array;
    }
   
    public function count(){
        return count($this->array);
    }
     
    public function at($entity_index)
    {
        return $this->read_key($entity_index);
    }
    
    /**
     * @param $array
     * @throws Exception
     */
    private function throwExceptionIfNotArray($array)
    {
        if (!is_array($array)) {
            throw new Exception("expects array as input for reader constructor");
        }
    }

}