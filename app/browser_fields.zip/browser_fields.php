<?php

abstract class BrowserField{

    //====================================
    abstract protected function getName();

    /** @return FileInput */
    public function toFileInput($default_value=''){
        return $this->setUpField(new FileInput(), $default_value);
    }

    /** @return TextInput */
    public function toTextInput($default_value=null){
        $value_from_browser = $this->value();
        $default_value = strlen($value_from_browser) > 0 ? $value_from_browser : $default_value;
        return $this->setUpField(new TextInput(), $default_value);
    }
    public function toTextArea($default_value=""){
        $value_from_browser = $this->value();
        $default_value = strlen($value_from_browser) > 0 ? $value_from_browser : $default_value;
        $text_area = new SmartTextarea();
        $text_area->set_name($this->getName());
        $text_area->add_child($default_value);
        return $text_area;
    }
    public function toPasswordInput($default_value=''){
        return $this->setUpField(new PasswordInput(), $default_value);
    }
    public function toHiddenInput($default_value=''){
        return $this->setUpField(new HiddenInput(), $default_value);
    }
    public function toRadioInput($default_value=''){
        return $this->setUpField(new RadioInput(), $default_value);
    }
    public function toSearchInput($default_value=''){
        return $this->setUpField(new SearchInput(), $default_value);
    }

    private function setUpField($text_input_box, $default_value)
    {
        $text_input_box->set_name($this->getName());
        $text_input_box->set_value($default_value);
        return $text_input_box;
    }

    public function readValueFromArray($array){
        if(!is_array($array)){
            throw new Exception("expects array as input");
        }
        return $this->read_key($this->getName(),$array);

    }
    protected function read_key($key,$array){
        $value = array_key_exists($key,$array)? $array[$key]:"";
        $value = $this->should_escape_html_special_chars && is_string($value) ? htmlspecialchars($value): $value;
        $value = $this->should_decode_as_utf8 && is_string($value) ? utf8_decode($value): $value;//todo:order matters: encoding should be last!!
        return $value;
    }
    private $should_escape_html_special_chars = true;
    private $should_decode_as_utf8 = false;

    private function writeValueToArray($value,$array){
        if(!is_array($array)){
            throw new Exception("expects array as input");
        }
        $array[$this->getName()] = $value;
    }

    protected function trimWhiteSpaceBeforeReturnValue(){
        return false;
    }
    public function value(){
        $original_value =  $this->readValueFromArray($_REQUEST);
        $final_value = $this->trimWhiteSpaceBeforeReturnValue() ? trim($original_value) : $original_value;
        return $final_value;
    }

    public function valueAsCurrency(){
        return SmartUtils::format_as_currency($this->value());
    }
    public function valueAsCommaSeparated(){
        return SmartUtils::createCommaSeparatedNumber($this->value());
    }

    public function writeToRequestArray($value){
        $this->writeValueToArray($value,$_REQUEST);
    }

    public function __toString()
    {
        return $this->value();
    }
}
class BrowserFieldForContent extends BrowserField{
    protected function getName()
    {
        return app::values()->content();
    }
}
class BrowserFieldForExtendedPostContent extends BrowserField{
    protected function getName()
    {
        return app::values()->extended_post_content();
    }
}

class BrowserFieldForKeywords extends BrowserField{
    protected function getName()
    {
        return app::values()->keywords();
    }
}
class BrowserFieldForCategory extends BrowserField{
    protected function getName()
    {
        return app::values()->category();
    }
}
class BrowserFieldForTitle extends BrowserField{
    protected function getName()
    {
        return app::values()->title();
    }
}

class BrowserFieldForSectionId extends BrowserField{
    protected function getName()
    {
        return app::values()->section_id();
    }
}
class BrowserFieldForTargetPageId extends BrowserField{
    protected function getName()
    {
        return app::values()->target_page_id();
    }
}

class BrowserFieldForFileToUpload extends BrowserField{
    protected function getName()
    {
        return app::values()->file_to_upload();
        
    }
}
class BrowserFieldForFileName extends BrowserField{
    protected function getName()
    {
        return app::values()->file_name();

    }
}

class BrowserFieldForPage extends BrowserField{
    protected function getName()
    {
        return app::values()->page();
    }
    public function toPage(){
        $page = null;
        switch ($this->value()){
            case app::values()->admin():
                $page = ui::pages()->admin();
                break;
            case app::values()->admin_add_images():
                $page = ui::pages()->admin_add_images();
                break;
            case app::values()->admin_view_posts():
                $page = ui::pages()->admin_view_posts();
                break;
            case app::values()->admin_view_posts_published():
                $page = ui::pages()->admin_view_posts_published();
                break;
            case app::values()->admin_edit_post():
                $page = ui::pages()->admin_edit_post();
                break;
            case app::values()->admin_edit_post_title():
                $page = ui::pages()->admin_edit_post_title();
                break;
            case app::values()->admin_edit_post_content():
                $page = ui::pages()->admin_edit_post_content();
                break;
            case app::values()->admin_edit_extended_post_content():
                $page = ui::pages()->admin_edit_extended_post_content();
                break;
            case app::values()->admin_edit_post_picture():
                $page = ui::pages()->admin_edit_post_picture();
                break;
            
            case app::values()->get_post():
                $page = ui::pages()->get_post();
                break;
            case app::values()->attach_image_to_post():
                $page = ui::pages()->attach_image_to_post();
                break;

            default:
                $page = ui::pages()->home();
                break;
        }
        return $page;

    }
}

class BrowserFieldForCmd extends BrowserField{
    protected function getName()
    {
        return app::values()->cmd();
    }
    protected function trimWhiteSpaceBeforeReturnValue(){
        return true;
    }
    public function toCmd(){
        $cmd = null;
        $value = $this->value();
        
        switch ($value){
            case "":
                $cmd = app::cmds()->notifyEmptyCmd();
                break;
            case app::values()->start_new_post():
                $cmd = app::cmds()->startNewPost();
                break;
            case app::values()->create_multiple_posts():
                $cmd = app::cmds()->createMultiplePosts();
                break;
            case app::values()->delete_post():
                $cmd = app::cmds()->deletePost();
                break;
            case app::values()->publish_post():
                $cmd = app::cmds()->publishPost();
                break;
            case app::values()->admin_edit_post_title():
                $cmd = app::cmds()->edit_post_title();
                break;
            case app::values()->admin_edit_post_content():
                $cmd = app::cmds()->edit_post_content();
                break;
            case app::values()->admin_edit_post_picture():
                $cmd = app::cmds()->edit_post_picture();
                break;
            case app::values()->admin_edit_extended_post_content():
                $cmd = app::cmds()->edit_extended_post_content();
                break;
            case app::values()->add_post():
                $cmd = app::cmds()->addPost();
                break;
            case app::values()->add_image():
                $cmd = app::cmds()->addImage();
                break;
            case app::values()->attach_image_to_post():
                $cmd = app::cmds()->attachImageToPost();
                break;
            case app::values()->get_post():
                $cmd = app::cmds()->GetPost();
                break;
            case app::values()->get_posts():
                $cmd = app::cmds()->GetPosts();
                break;
            case app::values()->get_data_page():
                $cmd = app::cmds()->GetDataPage();
                break;
            default:
                $cmd = app::cmds()->doNothing();
                break;
        }
        return $cmd;
    }
}